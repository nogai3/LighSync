if you want to replace the video with yours, change the valve.avi file to yours
or change 6am.avi file to your